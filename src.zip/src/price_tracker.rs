use ethers::prelude::*;
use ethers::types::{H160, H256, Log, I256};
use std::sync::Arc;
use crate::cache::{ReserveCache, PoolType};
use crate::bindings::{UniswapV3Pool};
use futures::StreamExt;
use ethers::abi::{decode, ParamType};

/// Start the price tracker: subscribe to V2 Sync and V3 Swap events, update ReserveCache in real time.
pub async fn start_price_tracker(
    ws_provider: Arc<Provider<Ws>>,
    http_provider: Arc<Provider<Http>>,
    reserve_cache: Arc<ReserveCache>,
) -> anyhow::Result<()> {
    // Collect all V2 and V3 pool addresses from the cache
    let mut v2_addresses = vec![];
    let mut v3_addresses = vec![];
    for entry in reserve_cache.iter() {
        match entry.value().pool_type {
            PoolType::V2 => v2_addresses.push(*entry.key()),
            PoolType::V3 => v3_addresses.push(*entry.key()),
        }
    }

    // Topics
    let v2_sync_topic = H256::from(ethers::utils::keccak256(b"Sync(uint112,uint112)"));
    let v3_swap_topic = H256::from(ethers::utils::keccak256(b"Swap(address,address,int256,int256,uint160,uint128,int24)"));

    // Deep debug: print topic hash and address info
    println!("[DEBUG] v3_swap_topic = 0x{:x}", v3_swap_topic);
    println!("[DEBUG] v3_addresses.len() = {}", v3_addresses.len());
    // for (i, addr) in v3_addresses.iter().take(5).enumerate() {
    //     println!("[DEBUG] V3 pool address [{}]: {:?}", i, addr);
    // }

    // V2 Sync subscription
    let v2_filter = Filter::new()
        .topic0(v2_sync_topic)
        .address(v2_addresses.clone());
    let reserve_cache_v2 = reserve_cache.clone();
    let ws_provider_v2 = ws_provider.clone();
    tokio::spawn(async move {
        let mut v2_stream = ws_provider_v2.subscribe_logs(&v2_filter).await.expect("V2 WS subscribe");
        while let Some(log) = v2_stream.next().await {
            if let Err(e) = handle_v2_sync_event(log, &reserve_cache_v2).await {
                eprintln!("[V2 Sync] Error: {}", e);
            }
        }
    });

    // V3 Swap subscription
    println!("[DEBUG] Subscribing to V3 Swap logs for {} pools", v3_addresses.len());
    // --- Try with only topic filter (no address) ---
    let v3_filter_topic_only = Filter::new().topic0(v3_swap_topic);
    // --- Try with only 1-2 addresses ---
    let v3_filter_few_addrs = if v3_addresses.len() >= 2 {
        Filter::new().topic0(v3_swap_topic).address(vec![v3_addresses[0], v3_addresses[1]])
    } else {
        Filter::new().topic0(v3_swap_topic)
    };
    // --- Try with all addresses (original) ---
    let v3_filter_all = Filter::new().topic0(v3_swap_topic).address(v3_addresses.clone());

    let reserve_cache_v3 = reserve_cache.clone();
    let http_provider_v3 = http_provider.clone();
    let ws_provider_v3 = ws_provider.clone();
    // --- Use topic-only filter for now ---
    tokio::spawn(async move {
        let mut v3_stream = ws_provider_v3.subscribe_logs(&v3_filter_topic_only).await.expect("V3 WS subscribe (topic only)");
        while let Some(log) = v3_stream.next().await {
            // println!("[DEBUG] V3 raw log: {:?}", log);
            if let Err(e) = handle_v3_swap_event(log, &reserve_cache_v3, &http_provider_v3).await {
                eprintln!("[V3 Swap] Error: {}", e);
            }
        }
    });

    // --- Uncomment below to try with only 1-2 addresses ---
    /*
    let reserve_cache_v3 = reserve_cache.clone();
    let http_provider_v3 = http_provider.clone();
    let ws_provider_v3 = ws_provider.clone();
    tokio::spawn(async move {
        let mut v3_stream = ws_provider_v3.subscribe_logs(&v3_filter_few_addrs).await.expect("V3 WS subscribe (few addrs)");
        while let Some(log) = v3_stream.next().await {
            println!("[DEBUG] V3 raw log (few addrs): {:?}", log);
            if let Err(e) = handle_v3_swap_event(log, &reserve_cache_v3, &http_provider_v3).await {
                eprintln!("[V3 Swap] Error: {}", e);
            }
        }
    });
    */

    // --- Uncomment below to try with all addresses (original) ---
    /*
    let reserve_cache_v3 = reserve_cache.clone();
    let http_provider_v3 = http_provider.clone();
    let ws_provider_v3 = ws_provider.clone();
    tokio::spawn(async move {
        let mut v3_stream = ws_provider_v3.subscribe_logs(&v3_filter_all).await.expect("V3 WS subscribe (all addrs)");
        while let Some(log) = v3_stream.next().await {
            println!("[DEBUG] V3 raw log (all addrs): {:?}", log);
            if let Err(e) = handle_v3_swap_event(log, &reserve_cache_v3, &http_provider_v3).await {
                eprintln!("[V3 Swap] Error: {}", e);
            }
        }
    });
    */

    Ok(())
}

/// Handle a V2 Sync event: decode reserves and update the cache.
async fn handle_v2_sync_event(log: Log, reserve_cache: &Arc<ReserveCache>) -> anyhow::Result<()> {
    use primitive_types::U256;
    // Sync(address indexed pair, uint112 reserve0, uint112 reserve1)
    if log.data.0.len() < 64 {
        anyhow::bail!("Invalid Sync log data");
    }
    let reserve0 = U256::from_big_endian(&log.data.0[0..32]);
    let reserve1 = U256::from_big_endian(&log.data.0[32..64]);
    let pool = log.address;
    if let Some(mut state) = reserve_cache.get_mut(&pool) {
        state.reserve0 = Some(reserve0);
        state.reserve1 = Some(reserve1);
        state.last_updated = chrono::Utc::now().timestamp() as u64;
        // println!("[V2 Sync] Updated pool {:?}: reserve0 = {}, reserve1 = {}, last_updated = {}", pool, reserve0, reserve1, state.last_updated);
    }
    Ok(())
}

/// Handle a V3 Swap event: decode from log data and update the cache.
async fn handle_v3_swap_event(log: Log, reserve_cache: &Arc<ReserveCache>, _http_provider: &Arc<Provider<Http>>) -> anyhow::Result<()> {
    use primitive_types::U256;

    if log.data.0.len() != 160 {
        eprintln!("[V3 Swap] Unexpected log data size: {}", log.data.0.len());
        anyhow::bail!("Invalid V3 Swap log size: {}", log.data.0.len());
    }

    let decoded = decode(
        &[
            ParamType::Int(256),     // amount0
            ParamType::Int(256),     // amount1
            ParamType::Uint(160),    // sqrtPriceX96
            ParamType::Uint(128),    // liquidity
            ParamType::Int(24),      // tick
        ],
        &log.data.0,
    )?;

    let sqrt_price_x96 = decoded[2].clone().into_uint().unwrap();
    let liquidity = decoded[3].clone().into_uint().unwrap();
    let tick_token = decoded[4].clone().into_int().unwrap();
    let tick: i32 = I256::from_raw(tick_token).as_i32();

    let pool = log.address;
    if let Some(mut state) = reserve_cache.get_mut(&pool) {
        state.sqrt_price_x96 = Some(sqrt_price_x96);
        state.liquidity = Some(liquidity);
        state.tick = Some(tick);
        state.last_updated = chrono::Utc::now().timestamp() as u64;
        // println!("[V3 Swap] Updated pool {:?}: sqrt_price_x96 = {}, tick = {}, liquidity = {}, last_updated = {}", pool, sqrt_price_x96, tick, liquidity, state.last_updated);
    } else {
        // println!("[V3 Swap] log for pool {:?} (not in reserve_cache!)", pool);
    }

    Ok(())
}
