use crate::simulate_swap_path::simulate_multi_hop_v2_v3;
use crate::cache::ReserveCache;
use dashmap::DashMap;
use std::collections::{HashMap, HashSet};
use ethers::types::H160;
use primitive_types::U256;

#[derive(Debug, Clone)]
pub struct BestRoutePair {
    pub base_token: H160,
    pub buy_tokens: Vec<H160>,
    pub buy_pools: Vec<H160>,
    pub sell_tokens: Vec<H160>,
    pub sell_pools: Vec<H160>,
    pub profit: U256,
}

pub async fn preload_route_cache(
    base_tokens: &[H160],
    tracked_tokens: &HashSet<H160>,
    all_paths: &HashMap<H160, Vec<(Vec<H160>, Vec<H160>)>>,  // tokenX -> [(tokens, pools)]
    reserve_cache: &ReserveCache,
    route_cache: &DashMap<H160, BestRoutePair>,
) {
    for &token_x in tracked_tokens {
        let mut best_buy: Option<(Vec<H160>, Vec<H160>, U256)> = None;
        let mut best_sell: Option<(Vec<H160>, Vec<H160>, U256)> = None;

        let Some(candidate_paths) = all_paths.get(&token_x) else {
            continue;
        };

        for (tokens, pools) in candidate_paths {
            if tokens.len() != pools.len() + 1 {
                continue;
            }

            let from_token = tokens.first().unwrap();
            let to_token = tokens.last().unwrap();

            if base_tokens.contains(from_token) && to_token == &token_x {
                // Buy path: base → ... → tokenX
                if let Some(output) = simulate_multi_hop_v2_v3(U256::exp10(18), tokens, pools, reserve_cache) {
                    if best_buy.is_none() || output > best_buy.as_ref().unwrap().2 {
                        best_buy = Some((tokens.clone(), pools.clone(), output));
                    }
                }
            }

            if base_tokens.contains(to_token) && from_token == &token_x {
                // Sell path: tokenX → ... → base
                if let Some(output) = simulate_multi_hop_v2_v3(U256::exp10(18), tokens, pools, reserve_cache) {
                    if best_sell.is_none() || output > best_sell.as_ref().unwrap().2 {
                        best_sell = Some((tokens.clone(), pools.clone(), output));
                    }
                }
            }
        }

        if let (Some((buy_tokens, buy_pools, buy_out)), Some((sell_tokens, sell_pools, sell_out))) = (best_buy, best_sell) {
            if let Some(base_token) = buy_tokens.first() {
                let profit = sell_out.saturating_sub(U256::exp10(18)); // 1 base token in

                route_cache.insert(token_x, BestRoutePair {
                    base_token: *base_token,  // Use the actual base token address
                    buy_tokens,
                    buy_pools,
                    sell_tokens,
                    sell_pools,
                    profit,
                });
            }
        }
    }
}
