use ethers::types::H160;
use primitive_types::U256;
use smallvec::SmallVec;
use dashmap::DashMap;
use std::collections::HashMap;
use std::collections::{VecDeque, HashSet};
use std::sync::Arc;
use rayon::prelude::*;
// use crate::router::BestRoutePair; // Assume this is defined in router module

#[derive(Debug, Clone)]
pub struct BestRoute {
    pub base_token: H160,
    pub target_token: H160,
    pub tokens: SmallVec<[H160; 4]>,  // up to 3 hops = 4 tokens
    pub pools: SmallVec<[H160; 3]>,   // max 3 pools
    pub amount_out: U256,
}

pub type BuyRouteMap = DashMap<H160, BestRoute>;   // tokenX => best buy route
pub type SellRouteMap = DashMap<H160, BestRoute>;  // tokenX => best sell route

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PoolVariant {
    V2,
    V3,
}

#[derive(Debug, Clone)]
pub struct Edge {
    pub to_token: H160,
    pub pool: H160,
    pub variant: PoolVariant,
}

#[derive(Debug, Default)]
pub struct TokenGraph {
    pub graph: HashMap<H160, Vec<Edge>>,
}

impl TokenGraph {
    /// Add a bidirectional edge between tokenA <-> tokenB
    pub fn add_pool(&mut self, token_a: H160, token_b: H160, pool: H160, variant: PoolVariant) {
        self.graph.entry(token_a).or_default().push(Edge {
            to_token: token_b,
            pool,
            variant,
        });
        self.graph.entry(token_b).or_default().push(Edge {
            to_token: token_a,
            pool,
            variant,
        });
    }

    /// Get neighbors of a token (used during BFS traversal)
    pub fn get_neighbors(&self, token: &H160) -> &[Edge] {
        self.graph.get(token).map(|v| v.as_slice()).unwrap_or(&[])
    }
}

#[derive(Debug, Clone)]
pub struct RoutePath {
    pub tokens: Vec<H160>,      // tokenA → tokenB → tokenX
    pub pools: Vec<H160>,       // corresponding pools
    pub variants: Vec<PoolVariant>,
    pub amount_out: U256,
}

/// BFS-based best buy route finder: base_token -> ... -> target_token (max_hops)
pub fn find_best_route_bfs(
    base_token: H160,
    target_token: H160,
    reserve_cache: &crate::cache::ReserveCache,
    graph: &TokenGraph,
    max_hops: usize,
    base_amount_in: U256,
) -> Option<RoutePath> {
    let mut visited = HashSet::new();
    let mut queue = VecDeque::new();

    // Each element: (path_tokens, path_pools, pool_variants)
    queue.push_back((vec![base_token], vec![], vec![]));
    let mut best_output = U256::zero();
    let mut best_path: Option<RoutePath> = None;

    while let Some((path, pools, variants)) = queue.pop_front() {
        let last_token = *path.last().unwrap();

        if path.len() - 1 > max_hops {
            continue;
        }

        for edge in graph.get_neighbors(&last_token) {
            if path.contains(&edge.to_token) {
                continue; // avoid loops
            }

            let mut new_path = path.clone();
            new_path.push(edge.to_token);

            let mut new_pools = pools.clone();
            new_pools.push(edge.pool);

            let mut new_variants = variants.clone();
            new_variants.push(edge.variant);

            // Only simulate if we're at the destination
            if edge.to_token == target_token {
                if let Some(out) = crate::simulate_swap_path::simulate_multi_hop_v2_v3(
                    reserve_cache,
                    &new_path,
                    &new_pools,
                    &new_variants,
                    base_amount_in,
                ) {
                    if out > best_output {
                        best_output = out;
                        best_path = Some(RoutePath {
                            tokens: new_path.clone(),
                            pools: new_pools.clone(),
                            variants: new_variants.clone(),
                            amount_out: out,
                        });
                    }
                }
            }

            queue.push_back((new_path, new_pools, new_variants));
        }
    }

    best_path
}

/// BFS-based best sell route finder: token_x -> ... -> base_token (max_hops)
pub fn find_best_sell_route_bfs(
    token_x: H160,
    base_token: H160,
    reserve_cache: &crate::cache::ReserveCache,
    graph: &TokenGraph,
    max_hops: usize,
    sell_amount_in: U256,
) -> Option<RoutePath> {
    let mut visited = HashSet::new();
    let mut queue = VecDeque::new();

    queue.push_back((vec![token_x], vec![], vec![]));
    let mut best_output = U256::zero();
    let mut best_path: Option<RoutePath> = None;

    while let Some((path, pools, variants)) = queue.pop_front() {
        let last_token = *path.last().unwrap();

        if path.len() - 1 > max_hops {
            continue;
        }

        for edge in graph.get_neighbors(&last_token) {
            if path.contains(&edge.to_token) {
                continue;
            }

            let mut new_path = path.clone();
            new_path.push(edge.to_token);

            let mut new_pools = pools.clone();
            new_pools.push(edge.pool);

            let mut new_variants = variants.clone();
            new_variants.push(edge.variant);

            if edge.to_token == base_token {
                if let Some(out) = crate::simulate_swap_path::simulate_multi_hop_v2_v3(
                    reserve_cache,
                    &new_path,
                    &new_pools,
                    &new_variants,
                    sell_amount_in,
                ) {
                    if out > best_output {
                        best_output = out;
                        best_path = Some(RoutePath {
                            tokens: new_path.clone(),
                            pools: new_pools.clone(),
                            variants: new_variants.clone(),
                            amount_out: out,
                        });
                    }
                }
            }

            queue.push_back((new_path, new_pools, new_variants));
        }
    }

    best_path
}

/// Parallel precompute of best buy/sell routes for all tracked tokens, storing in DashMap
pub fn precompute_best_routes(
    base_token: H160,
    tracked_tokens: &[H160],
    reserve_cache: Arc<crate::cache::ReserveCache>,
    graph: Arc<TokenGraph>,
    route_cache: Arc<DashMap<H160, crate::router::BestRoutePair>>,
    amount_in: U256,
    max_hops: usize,
) {
    tracked_tokens.par_iter().for_each(|&token_x| {
        if token_x == base_token {
            return;
        }

        let buy = find_best_route_bfs(
            base_token,
            token_x,
            &reserve_cache,
            &graph,
            max_hops,
            amount_in,
        );

        let sell = find_best_sell_route_bfs(
            token_x,
            base_token,
            &reserve_cache,
            &graph,
            max_hops,
            amount_in,
        );

        if let (Some(buy_route), Some(sell_route)) = (buy, sell) {
            route_cache.insert(
                token_x,
                crate::router::BestRoutePair {
                    base_token,
                    buy_tokens: buy_route.tokens,
                    buy_pools: buy_route.pools,
                    sell_tokens: sell_route.tokens,
                    sell_pools: sell_route.pools,
                    profit: sell_route.amount_out.saturating_sub(amount_in),
                },
            );
        }
    });
} 