mod config;
mod fetch_pairs;
mod cache;
mod bindings;
mod price_tracker;
mod route_cache;
mod simulate_swap_path;

use config::Config;
use fetch_pairs::{PairFetcher, PairInfo};
use cache::{ReserveCache};
use ethers::providers::{Provider, Http, Ws};
use std::sync::Arc;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::time::Duration;
use dashmap::DashMap;
use std::collections::HashMap;
use ethers::types::H160;
use once_cell::sync::Lazy;
use std::sync::RwLock;
use primitive_types::U256;
use route_cache::BestRoutePair;

#[tokio::main]
async fn main() {
    println!("Starting pair fetcher...");
    let config = Config::default();

    // Load pairs from files
    let mut pairs: Vec<PairInfo> = Vec::new();
    let mut v3_count = 0;
    for file_path in ["data/pairs_v2.jsonl", "data/pairs_v3.jsonl"] {
        if let Ok(file) = File::open(file_path) {
            let reader = BufReader::new(file);
            for line in reader.lines() {
                if let Ok(line) = line {
                    if let Ok(pair) = serde_json::from_str::<PairInfo>(&line) {
                        if pair.dex_version == config::DexVersion::V3 {
                            v3_count += 1;
                        }
                        pairs.push(pair);
                    }
                }
            }
        }
    }
    println!("Loaded {} pairs from files ({} V3 pairs).", pairs.len(), v3_count);

    // Build token index (H160 <-> u16)
    let mut all_tokens_set = std::collections::HashSet::new();
    for pair in &pairs {
        all_tokens_set.insert(pair.token0);
        all_tokens_set.insert(pair.token1);
    }
    let all_tokens_vec: Vec<H160> = all_tokens_set.into_iter().collect();
    let token_to_index: HashMap<H160, u16> = all_tokens_vec.iter().enumerate().map(|(i, &t)| (t, i as u16)).collect();
    let index_to_token: Vec<H160> = all_tokens_vec.clone();
    let num_tokens = index_to_token.len();

    // Convert base_tokens and all_tokens to indices, with warning for missing
    let mut base_tokens: Vec<u16> = Vec::new();
    let mut base_tokens_h160: Vec<H160> = Vec::new();
    for b in &config.base_tokens {
        match token_to_index.get(&b.address) {
            Some(&idx) => {
                base_tokens.push(idx);
                base_tokens_h160.push(b.address);
            },
            None => println!("WARNING: Base token {:?} not found in pairs file, skipping!", b.address),
        }
    }
    let all_tokens: Vec<u16> = (0..num_tokens as u16).collect();
    let all_tokens_h160: Vec<H160> = index_to_token.clone();

    // Build providers and cache
    let provider = Arc::new(Provider::<Http>::try_from(&config.rpc_url).expect("provider"));
    let ws_provider = Arc::new(Provider::<Ws>::connect(&config.ws_url).await.expect("ws provider"));
    let reserve_cache = Arc::new(ReserveCache::default());

    // Preload reserves in parallel
    println!("Preloading reserves for all pools...");
    cache::preload_reserve_cache(&pairs, provider.clone(), &reserve_cache, 200).await;
    println!("Reserve cache loaded: {} pools", reserve_cache.len());

    // --- Build fee map: pool address -> fee (bps) ---
    let mut factory_to_fee: HashMap<H160, u32> = HashMap::new();
    for dex in &config.dexes {
        factory_to_fee.insert(dex.factory_address, dex.fee);
    }
    let mut fee_map: HashMap<H160, u32> = HashMap::new();
    for pair in &pairs {
        let fee = factory_to_fee.get(&pair.factory_address).copied().unwrap_or(25);
        fee_map.insert(pair.pair_address, fee);
    }

    // --- Build base_amount_map: base token -> default amount (e.g. 1000 * 10^decimals) ---
    let mut base_amount_map: HashMap<H160, U256> = HashMap::new();
    for b in &config.base_tokens {
        let decimals = b.decimals as u32;
        let amount = U256::from(1000u64) * U256::from(10u64.pow(decimals));
        base_amount_map.insert(b.address, amount);
    }

    // Build safe_tokens set as H160 (for memory-efficient filtering)
    let safe_tokens: std::collections::HashSet<H160> = all_tokens_h160.iter().cloned().collect();

    // --- Preload route cache (test integration) ---
    let route_cache = DashMap::<H160, BestRoutePair>::new();
    // Dummy all_paths: tokenX -> [(tokens, pools)]
    let all_paths: std::collections::HashMap<H160, Vec<(Vec<H160>, Vec<H160>)>> = std::collections::HashMap::new();
    // Call preload_route_cache (async)
    route_cache::preload_route_cache(
        &base_tokens_h160,
        &safe_tokens,
        &all_paths,
        &reserve_cache,
        &route_cache
    ).await;
    println!("Route cache loaded: {} routes", route_cache.len());

    // Start price tracker
    println!("Starting price tracker (WS event listener)...");
    price_tracker::start_price_tracker(ws_provider.clone(), provider.clone(), reserve_cache.clone()).await.expect("price tracker");
    println!("Price tracker running. Listening for events...");

    // // Keep the process alive until Ctrl+C
    // tokio::signal::ctrl_c().await.expect("failed to listen for ctrl_c");
    // println!("Shutting down...");
}
