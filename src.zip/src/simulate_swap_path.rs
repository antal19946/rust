use ethers::types::H160;
use primitive_types::U256;
use crate::cache::{ReserveCache, PoolType};

// --- Uniswap V2 getAmountOut formula ---
pub fn get_amount_out_v2(amount_in: U256, reserve_in: U256, reserve_out: U256) -> Option<U256> {
    if amount_in.is_zero() || reserve_in.is_zero() || reserve_out.is_zero() {
        return None;
    }
    let amount_in_with_fee = amount_in * 997u32;
    let numerator = amount_in_with_fee * reserve_out;
    let denominator = reserve_in * 1000u32 + amount_in_with_fee;
    Some(numerator / denominator)
}

// --- Uniswap V3 (placeholder: just returns input for now) ---
pub fn simulate_uniswap_v3_swap(
    amount_in: U256,
    _input_token: H160,
    _output_token: H160,
    _sqrt_price_x96: U256,
    _liquidity: U256,
    _tick: i32,
) -> Option<U256> {
    // TODO: Implement real V3 math. For now, just return input as output.
    Some(amount_in)
}

pub fn simulate_multi_hop_v2_v3(
    mut amount_in: U256,
    tokens: &[H160],
    pools: &[H160],
    reserve_cache: &ReserveCache,
) -> Option<U256> {
    if tokens.len() < 2 || tokens.len() != pools.len() + 1 {
        return None;
    }

    for i in 0..pools.len() {
        let input_token = tokens[i];
        let output_token = tokens[i + 1];
        let pool = pools[i];

        let Some(res) = reserve_cache.get(&pool) else {
            return None;
        };
        let reserves = &*res;
        match reserves.pool_type {
            PoolType::V2 => {
                let (reserve_in, reserve_out) = if reserves.token0 == input_token {
                    (reserves.reserve0?, reserves.reserve1?)
                } else if reserves.token1 == input_token {
                    (reserves.reserve1?, reserves.reserve0?)
                } else {
                    return None; // token mismatch
                };
                amount_in = get_amount_out_v2(amount_in, reserve_in, reserve_out)?;
            }
            PoolType::V3 => {
                let sqrt_price_x96 = reserves.sqrt_price_x96?;
                let liquidity = reserves.liquidity?;
                let tick = reserves.tick?;
                amount_in = simulate_uniswap_v3_swap(
                    amount_in,
                    input_token,
                    output_token,
                    sqrt_price_x96,
                    liquidity,
                    tick,
                )?;
            }
        }
    }
    Some(amount_in)
}
